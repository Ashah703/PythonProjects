# Akash Shah
# 09 / 24 / 2019
# Project 2


def frame_score(the_frame, bonus1, bonus2):

    if the_frame[0] == 10:
        return 10 + bonus1 + bonus2
    elif the_frame[0] + the_frame[1] == 10:
        return 10 + bonus1

    else:
        the_frame[0] + the_frame[1] < 10
        return the_frame[0] + the_frame[1] 

   
