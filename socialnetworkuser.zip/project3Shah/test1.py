from socialnetworkuser import SocialNetworkUser



snu1 = SocialNetworkUser("Buckshot","4/17", "Single", "222-222-2222", "JitterBug")
print(snu1.screen_name)
print(snu1.birth_date)
print(snu1.relationship_status)
print(snu1.phone_number)
print(snu1.friends)
print(snu1)

snu1.add_friend("PonyTail")
snu1.add_friend("AppleJacks")
print(snu1.friends)
