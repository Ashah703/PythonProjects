# Akash Shah

# Project 3a - Social Network

# 10 / 02 / 2018


# Step 1 - Creating The Social Network class by adding in "class"


class SocialNetworkUser:

    def __init__(self,the_screen_name,the_birth_date,the_relationship_status,the_phone_number,the_friends):

        self.screen_name = the_screen_name
        self.birth_date = the_birth_date
        self.relationship_status = the_relationship_status
        self.phone_number = the_phone_number
        self.friends = [] 

# Step 2 - create the "add_friend" method
# as this registers "the_friend" variable"


    def add_friend(self,the_friend):
        self.friends.append(the_friend) 


    def __str__(self):              # str method formats the code
        return '''Name: {0:s}
Birth: {1:s}
Relationship: {2:s}
Phone: {3:s}
'''.format(self.screen_name, self.birth_date, self.relationship_status, self.phone_number)
    
