# Akash Shah
# Project 3b
# test 3

from socialnetworkuser import SocialNetworkUser
# Sets the array 
arr = [ ]

# Opens the selected file
fin1 = open("users.txt", "r")

# Disregards the first line 
fin1.readline( )

for line in fin1:
    fields = line.split(",")
    screen_name = fields[0].strip( )
    birth_date = fields[1].strip( )
    relationship_status = fields[2].strip( )
    phone_number = fields[3].strip( )
    s = SocialNetworkUser(screen_name, birth_date, relationship_status, phone_number)
    arr.append(s)

# Prints oject in array 
for p in arr:
    print(p)

# opens file and reads fin2 
fin2 = open("friends.txt", "r")

#Throws header line away 
fin2.readline( )

# line_number sets to 0

line_number = 0

for line in fin2:  #  reads data from friends.txt
    friends = line.strip( ).split(",")  # reads line.split to retreive list of friends
    for f in friends:
        arr[line_number].friends.append(f)
    line_number += 1


# Allows user to enter screen_name

desired_screen_name = input("Enter desired screen name: ")
for snu in arr:
    if snu.screen_name == desired_screen_name:
        print(f"Screen name: {snu.screen_name}"                  + " " + "\n"
              f"Birthdate: {snu.birth_date}"                     + " " + "\n"
              f"Relationship Status: {snu.relationship_status}"  + " " + "\n"
              f"Phone Number: {snu.phone_number}"                + " " + "\n"
              f"Friends: {snu.friends}")


