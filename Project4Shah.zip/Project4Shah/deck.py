from random import shuffle
from card import Card

class Deck:

    # Initialize deck to contain cards
    # numbered 1 to 20.
    def __init__(self):
        self._cards = [ ]
        for suit in ["C", "D", "H", "S"]:
            for rank in range(2, 15):
                self._cards.append(Card(rank, suit))

    # Shows deck as a string object.	
    def __str__(self):
        output = ""
        counter = 1
        for card in self._cards:
            output += " " + str(card)
            if counter % 20 == 0:
                output += "\n"
            counter += 1
        return output
	
    # Gets rid oftop card from the deck
    # and then return it.
    def deal(self):
        return self._cards.pop( )

    # Place a card to top of deck
    def add_to_top(self, the_card):
        self._cards.append(the_card)

    # Place a card to bottom of deck
    def add_to_bottom(self, the_card):
        self._cards.insert(0, the_card)

    # Returs number of cards in deck
    def count(self):
        return len(self._cards)

    # Returns True of deck is empty,
    # Or returns false.
    def is_empty(self):
        return len(self._cards) == 0

    # Randomizes the cards        
    def shuffle(self):
        shuffle(self._cards)

    
