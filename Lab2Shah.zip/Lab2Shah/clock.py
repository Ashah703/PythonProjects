#Akash Shah

# 09/24/2018

# Lab 2


class Clock:
    def __init__(self, the_hr, the_min, the_sec):
        self.hr = the_hr
        self.min = the_min
        self.sec = the_sec

    def tick(self):
        self.sec += 1

        if self.sec == 60:
            self.sec = 0
            self.min += 1

        if self.min == 60:
            self.min = 0
            self.sec += 0
            self.hr += 1

        if self.hr == 60:
            self.hr = 24
            self.sec += 0
            self.min += 0

    def __str__(self):

       return "{0:02d}:{1:02d}:{2:02d}".format(self.hr, self.min, self.sec)
 
