public class Date
{   
    public int year;
    public int month;
    public int day;
        
    public Date(int theYear, int theMonth, int theDay)
    {
       year = theYear;
       month = theMonth;
       day = theDay;
    }

    public String toString( )
    {   
        return String.format("%d/%d/%d",
            month, day, year);
    }
    
     public void nextDay( )
    {    
         int [ ] days_in_month = {0, 31, 28, 31, 30,
            31, 30, 31, 31, 30, 31, 30, 31};
         
         
         day++;
        
        if(day > days_in_month[month])
        { 
            day = 1;
            month++;
        }
        
        if(month == 13)
       
        { 
            month = 1;
            year++;
        }
        
    }
}