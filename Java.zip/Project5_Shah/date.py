# date.py module
# Translate to Java for Project 5
class Date:

    def __init__(self, the_year, the_mon, the_day):
        self.year = the_year
        self.mon = the_mon
        self.day = the_day

    def __str__(self):
        return f"{self.mon}/{self.day}/{self.year}"

    def next_day(self):
        days_in_month = [0, 31, 28, 31, 30, \
            31, 30, 31, 31, 30, 31, 30, 31]
        self.day += 1
        if self.day > days_in_month[self.mon]:
            self.mon += 1
            self.day = 1
        if self.mon == 13:
            self.year += 1
            self.mon = 1
