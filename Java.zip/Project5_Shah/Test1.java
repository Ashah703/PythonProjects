public class Test1    
{ 
    
    public static void main(String[ ] args)
        
        
    {   
        Date d1 = new Date(2013, 9, 18); 
        
        System.out.println(d1); 
        System.out.println(d1.year + " " + d1.month + " " + d1.day); 
        d1.nextDay(); 
        System.out.println(d1);  
        
        
        d1 = new Date(2013, 9, 31); 
        
        d1.nextDay();
        System.out.println(d1); 
        
        d1 = new Date(2013, 12, 31); 
        d1.nextDay();
        System.out.println(d1); 
        
        d1 = new Date(2017, 12, 31); 
        d1.nextDay();
        System.out.println(d1); 
        
    
        for(int i = 0; i < 365; i++)
        {
            d1.nextDay();
            System.out.println(d1);   
        }
        
    }


}