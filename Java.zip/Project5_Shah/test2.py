# test2.py module for testing Appointment class
# Translate to Java for Project 5
from appointment import Appointment

appt1 = Appointment("ot", "Year End Analysis", \
    "Room 207", 2018, 12, 28, 10,0)
print(appt1)

print(appt1.occurs_on(2018, 9, 3))
print(appt1.occurs_on(2018, 9, 4))

appt2 = Appointment("mo", "Room 203", \
    "Staff Meeting", 0, 0, 3, 8, 30)
print(appt2)
print( )

print(appt1.occurs_on(2018, 12, 28))
print(appt1.occurs_on(2012, 12, 25))
print(appt2.occurs_on(2018,  9, 3))
print(appt2.occurs_on(2012,  3, 3))
print(appt2.occurs_on(2018,  9, 7))
print(appt2.occurs_on(2012,  3, 7))
