# test3 module
# Display days of year on which
# appointments occur.
# Translate to Java for Project 5.
from appointment import Appointment
from date import Date

fin = open("appointments.txt", "r")

# Create list with size greater than needed.
arr = list([None] * 100)

line_number = 0
line = fin.readline( )
while line != "":
    fields   = line.split(",")
    appt_type= fields[0].strip( )
    location = fields[1].strip( )
    purpose  = fields[2].strip( )
    year     = int(fields[3].strip( ))
    mon      = int(fields[4].strip( ))
    day      = int(fields[5].strip( ))
    hour     = int(fields[6].strip( ))
    min      = int(fields[7].strip( ))
    appt     = Appointment(appt_type, location, \
        purpose, year, mon, day, hour, min)
    arr[line_number] = appt
    line_number += 1
    line = fin.readline( )

fin.close( )
num_appointments = line_number

# Print array of Appointment objects
for i in range(0, num_appointments):
    print(arr[i])

d = Date(2017, 12, 31)
for i in range(0, 365):
    d.next_day( )
    for i in range(0, num_appointments):
        if arr[i].occurs_on(d.year, d.mon, d.day):
            print(d, end=" ")
            print("{0:02d}:{1:02d}". \
                format(arr[i].hour, arr[i].min))
            print("   ", arr[i])
            print( )

    
