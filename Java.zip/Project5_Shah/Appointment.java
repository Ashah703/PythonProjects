// Akash Shah 
// 11/13/2018 
// Project 5 
// Appointment.java 


// initalizing the public class file for Appointment
public class Appointment
{   
    public String apptType; // creating the variables 
    public String location; 
    public String purpose; 
    public int year; 
    public int month; 
    public int day; 
    public int hour; 
    public int min; 
    
    public Appointment(String theApptType, String theLocation, String thePurpose, int theYear, int theMonth, int theDay, int theHour, int theMin)
    {
        apptType = theApptType;
        location = theLocation;
        purpose = thePurpose; 
        year = theYear;
        month = theMonth;
        day = theDay;
        hour = theHour;
        min = theMin; 
    }
// initalizing String to toString 
    public String toString( )
   
    {   
        return apptType + ";" + location + ";" + purpose + ";" + year   + ";" + month + ";" + day + ";" + hour + ";" + min;
    }
     
    public boolean occursOn(int theYear, int theMonth, int theDay)
  
    {  
        if (apptType.equals("ot"))
        
        {   
            return year == theYear    && 
                   month == theMonth  &&
                   day ==  theDay;    
        }    
           
        else  
        {
            return day == theDay;
        }
    }
}