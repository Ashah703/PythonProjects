# appointment.py module, containing Appointment class
# Translate to Java for Project 5
class Appointment:

    def __init__(self, the_appt_type, the_location, \
        the_purpose, the_year, the_mon, the_day, \
        the_hour, the_min):

        # Appointment type can be
        # "ot": one time appointment and
        # "mo": monthly appointment.
        self.appt_type = the_appt_type
        
        self.location = the_location
        self.purpose = the_purpose
        self.year = the_year
        self.mon = the_mon
        self.day = the_day
        self.hour = the_hour
        self.min = the_min

    def __str__(self):
        
        output = f"{self.location} {self.purpose}"
        return output

    def occurs_on(self, the_year, the_mon, the_day):

        # A one time appointment only occurs on the
        # given year, month and day.
        if self.appt_type == "ot":
            return self.year == the_year and \
               self.mon  == the_mon  and \
               self.day  == the_day

        # A monthly appointment occurs every month
        # on the given day.
        elif self.appt_type == "mo":
            return self.day == the_day
    
