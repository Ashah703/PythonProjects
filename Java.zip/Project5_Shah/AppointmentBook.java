public class AppointmentBook 

{     
    public String appt;
    
    public String location; 
    
    public String purpose; 
    
    public int year; 
    
    public int month; 
    
    public int day; 
    
    public int hour; 
    
    public int min; 
    
    
    public AppointmentBook(String apptType, String theLocation, String thePurpose, int theYear, int theMon, int theDay, int theHour, int theMin)
        
    {
        appt = apptType; 
        location = theLocation;
        purpose = thePurpose; 
        year = theYear; 
        month = theMon; 
        day = theDay; 
        hour = theHour; 
        min = theMin; 
    }
    
    
    public String toString() 
        
    { 
        return appt + ";" + location + ";" + purpose + ";" + year + ";" + month + ";" + day + ";" + hour + ";" + min; 
    }
    
    
    
    public void occursOn() 
    {
        year++;
        month++;
        day++; 
    }
    
    
}

