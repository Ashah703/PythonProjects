//Akash Shah
//11/14/2018
// Test 3 

import java.util.Scanner;
import java.io.*;

public class Test3
{
    

    public static void main(String[ ] args)
        throws FileNotFoundException
    {
        
        Appointment[ ] arr = new Appointment[1000];
        
       
        Scanner s = new Scanner(
            new File("appointments.txt"));
        
       
 
        
        int lineNumber = 0;
        
       
        while(s.hasNextLine( ))
        {
          
            String line = s.nextLine( );
            String[ ] fields = line.split(",");
            String appType = fields[0];
            String location = fields[1];
            String purpose = fields[2];
            int year = Integer.parseInt (fields[3]);
            int mon = Integer.parseInt (fields[4]);
            int day = Integer.parseInt (fields[5]);
            int hour = Integer.parseInt (fields[6]);
            int min = Integer.parseInt (fields[7]);
             
            
        
            Appointment appt = new Appointment(appType, location, purpose, year, mon, day, hour, min);
            
		
            arr[lineNumber] = appt;
            
			lineNumber++;
			
            
        }
        
		int num_appointments = lineNumber;
		
		for(int i = 0; i < num_appointments; i++){
			System.out.println(arr[i]);
		}
 
		num_appointments = arr.length;
		 Date d = new Date (2017, 12, 31);
		 for(int i = 0; i < 356; i++){
			 d.nextDay();
			 for(int p = 0; p < num_appointments; i++){
                  if(arr[i].occursOn(d.year, d.month, d.day)) {
				        System.out.println(d + " ");
				        System.out.println(arr[p].hour + " " + arr[p].min);
				        System.out.println("   " + arr[p]);
				        System.out.println();
                  }
             }
         }
    }
}

                               



