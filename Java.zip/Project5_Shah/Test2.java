public class Test2  
 
{
    public static void main(String[] args)
    {   
        
        Appointment appt1 = new Appointment("ot", "Year End Analysis", "Room 207", 2018, 12, 28, 10, 0); 
        System.out.println(appt1); 
        System.out.println(appt1.apptType + " " + appt1.location + " " + appt1.purpose + " " + appt1.year+ " " + appt1.month + " " + appt1.day + " " + appt1.hour + " " + appt1.min); 
        
        
        Appointment appt2 = new Appointment("mo", "Room 203", "Staff Meeting", 0, 0, 3, 8, 30);
    
        System.out.println(appt1.occursOn(2018, 12, 28));
        System.out.println(appt1.occursOn(2012, 12, 25)); 
        System.out.println(appt2.occursOn(2018, 9, 3)); 
        System.out.println(appt2.occursOn(2012, 3, 3)); 
        System.out.println(appt2.occursOn(2018, 9, 7)); 
        System.out.println(appt2.occursOn(2012, 3, 7)); 
    }
}
