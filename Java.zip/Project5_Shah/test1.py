# date.py module
# Translate to Java for Project 6
from date import Date

d1 = Date(2013, 9, 18)
print(d1)
print(d1.year, d1.mon, d1.day)
d1.next_day( )
print(d1)
print( )

d2 = Date(2013, 9, 31)
print(d2)
d2.next_day( )
print(d2)
print( )

d3 = Date(2013, 12, 31)
print(d3)
d3.next_day( )
print(d3)

d = Date(2017, 12, 31)
for i in range(0, 365):
    d.next_day( )
    print(d)

