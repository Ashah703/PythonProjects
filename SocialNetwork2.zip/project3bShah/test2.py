# Akash Shah
# Project 3b
# test 2


import unittest


from socialnetworkuser import SocialNetworkUser



class MyUnitTestClass(unittest.TestCase):
        
    def test1(self):

        snu1 = SocialNetworkUser("Buckshot","4/17", "Single", "222-222-2222")
        self.assertEqual(snu1.screen_name, "Buckshot")
        self.assertEqual(snu1.birth_date, "4/17")
        self.assertEqual(snu1.relationship_status, "Single")
        self.assertEqual(snu1.phone_number, "222-222-2222")

        snu1.add_friend("JitterBug")
        snu1.add_friend("PonyTail")


        self.assertEqual(snu1.friends, ["JitterBug", "PonyTail"])

        
if __name__ == '__main__':
    unittest.main( )
