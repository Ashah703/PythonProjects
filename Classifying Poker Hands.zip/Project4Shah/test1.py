from card import Card
from deck import Deck


c = Card(12, "S")
print(c)
print(c.rank)
print(c.suit)
print(c.color())

d = Deck( )
print(d)
print(d.count( ))

c = d.deal( )
print(d)
print(d.count( ))

d.add_to_bottom(c)
print(d)
print(d.count( ))

d.add_to_top(Card(12, "S"))
print(d)
print(d.count( ))

d.shuffle( )
print (d)

c1 = Card(12, "S")

