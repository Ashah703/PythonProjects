# Akash Shah
# Project 4
# 10/31/2018

class Card:

    def __init__(self, the_rank, the_suit):
        self.rank = the_rank
        self.suit = the_suit

    def color(self):
        if self.suit == "C" or self.suit == "S":
            return "black"
        else:
            return "red"

 
    def __str__(self):
        symbols = ["0", "1", "2", "3", "4", "5", "6", "7", \
            "8", "9", "10", "J", "Q", "K", "A"]
        return symbols[self.rank] + self.suit

    def __repr__(self):
        return str(self)
    
    def __lt__(self, other):
        return self.rank < other.rank

    def __eq__(self, other):
        return self.rank == other.rank


    
