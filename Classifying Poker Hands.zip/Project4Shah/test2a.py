from card import Card
import unittest

class MyUnitTestClass(unittest.TestCase):
        
    def test_1(self):
        c1 = Card(12, "S")
        c2 = Card(14, "C")
        c3 = Card(12, "H")

        # _lt_ test

        self.assertEqual(c1 < c2, True)
        self.assertEqual(c1 > c3, False)
        
        # eq test 
        self.assertEqual(c1 == c2, False)
        self.assertEqual(c1 == c3, True)

if __name__ == '__main__':
    unittest.main( )
