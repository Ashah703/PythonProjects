more = input('Do you wish to input length in meters? ').upper()

while more[0] == 'Y':
    meter = float(input('Enter new length in meters: '))
    f = meter * 3.28084
    feet = int(f)
    inches = int(12.0 * (f - feet))

    print('The length is' , end = ' ')

    if feet == 1:
        print(str(feet) + ' foot ', end = ' ' )
    else:
        print(str(feet) + ' feet ', end = ' ')

    if inches == 1:
        print(str(inches) + ' inch ', end = ' ')
    elif inches > 1:
        print(str(inches) + ' inches ', end = ' ')
    else:
        print('.') 

